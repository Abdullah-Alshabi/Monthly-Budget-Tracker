import java.util.List;

public class Room {
    int numberOFComputer;
    int capasity;
    static int student = 1;
    String lightStatus = "OFF";
    void enter(Student s) {
        if(student > capasity) {
            System.out.println("class is full");
        }
        else{
            System.out.println("The student: " + s.getFullName() + " Entered the class.");
            student++;
        }
    }
    void leave (Student s) {
        System.out.println("The student: " + s.getFullName() + " left the class.");
        student--;
    }
    int getCapasity() {
        return capasity;
    }
    int getNumberOFComputer() {
        return numberOFComputer;
    }
}
