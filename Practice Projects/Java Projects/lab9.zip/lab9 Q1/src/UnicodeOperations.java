public class UnicodeOperations {
    public static int[] getUnicode(String aString) {
        int[] unicodeArray = new int[aString.length()];
        for (int i = 0; i < aString.length(); i++) {
            unicodeArray[i] = aString.charAt(i);
        }
        return unicodeArray;
    }

    public static boolean checkIfLetter(int[] intArray) {
        for (int value : intArray) {
            if ((value < 65 || value > 90) && (value < 97 || value > 122)) {
                return false; // Not a letter
            }
        }
        return true; // All elements are letters
    }

    public static boolean isEqualStrings(String aString1, String aString2) {
        int[] unicodeArray1 = getUnicode(aString1);
        int[] unicodeArray2 = getUnicode(aString2);

        if (unicodeArray1.length != unicodeArray2.length) {
            return false; // Different lengths mean strings are not equal
        }

        for (int i = 0; i < unicodeArray1.length; i++) {
            if (unicodeArray1[i] != unicodeArray2[i]) {
                return false; // Different characters found
            }
        }
        return true; // Strings are equal
    }

    public static void main(String[] args) {
        String StringVar1 = "This is OOP Lab";
        String StringVar2 = "This is OOP Lab";
        String StringVar3 = "This is OOP ";

        System.out.println(StringVar1.equals(StringVar2)); // true
        System.out.println(isEqualStrings(StringVar1, StringVar2)); // true
        System.out.println(isEqualStrings(StringVar2, StringVar3)); // false
    }
}
