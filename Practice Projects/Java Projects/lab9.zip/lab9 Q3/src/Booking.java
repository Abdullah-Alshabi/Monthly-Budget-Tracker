public class Booking {
    private final String customerName;
    private final TimeSlot timeSlot;

    public Booking(String customerName, TimeSlot timeSlot) {
        this.customerName = customerName;
        this.timeSlot = timeSlot;
    }

    public String getCustomerName() {
        return customerName;
    }

    public TimeSlot getTimeSlot() {
        return timeSlot;
    }
}
