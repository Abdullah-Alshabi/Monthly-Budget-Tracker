import java.util.ArrayList;
import java.util.List;

public class BookingManagementApp {
    private final String hotelName;
    private final List<Booking> bookings;

    public BookingManagementApp(String hotelName) {
        this.hotelName = hotelName;
        this.bookings = new ArrayList<>();
    }

    public void addCustomerBooking(Booking booking) {
        if (isTimeSlotAvailable(booking.getTimeSlot())) {
            bookings.add(booking);
            System.out.println("Booking added for: " + booking.getCustomerName());
        } else {
            System.out.println("Booking not added. Time slot is not available.");
        }
    }

    public boolean isTimeSlotAvailable(TimeSlot timeSlot) {
        for (Booking booking : bookings) {
            if (booking.getTimeSlot().isOverlappingWith(timeSlot)) {
                return false;
            }
        }
        return true;
    }

    public void printBookedSlots() {
        for (Booking booking : bookings) {
            System.out.println("Customer: " + booking.getCustomerName() + ", Time Slot: " + booking.getTimeSlot());
        }
    }

    public static void main(String[] args) {
        BookingManagementApp hotel1 = new BookingManagementApp("Java Hotel");
        TimeSlot appoint1 = new TimeSlot(2023, 10, 12, "11:30am", "12:00pm");
        TimeSlot appoint2 = new TimeSlot(2023, 10, 12, "11:30am", "12:00pm");
        TimeSlot appoint3 = new TimeSlot(2023, 10, 10, "11:30am", "12:00pm");

        boolean checkOverlap1 = appoint1.isOverlappingWith(appoint2);
        boolean checkOverlap2 = appoint1.isOverlappingWith(appoint3);

        Booking customer1Booking = new Booking("Ali Alkhaled", appoint1);
        Booking customer2Booking = new Booking("Jawad Noor", appoint2);

        hotel1.addCustomerBooking(customer1Booking);
        hotel1.addCustomerBooking(customer2Booking);

        boolean isAvailable = hotel1.isTimeSlotAvailable(appoint2);
        hotel1.printBookedSlots();
    }
}
