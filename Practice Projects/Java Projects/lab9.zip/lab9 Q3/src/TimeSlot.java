public class TimeSlot {
    private final int year;
    private final int month;
    private final int day;
    private final String startTime;
    private final String endTime;

    public TimeSlot(int year, int month, int day, String startTime, String endTime) {
        this.year = year;
        this.month = month;
        this.day = day;
        this.startTime = startTime;
        this.endTime = endTime;
    }

    public boolean isOverlappingWith(TimeSlot otherSlot) {
        // Your logic to check if two time slots overlap
        return this.year == otherSlot.year &&
                this.month == otherSlot.month &&
                this.day == otherSlot.day &&
                // Additional logic for time overlap check if needed
                // Assuming no time overlap for simplicity
                this.startTime.equals(otherSlot.startTime) &&
                this.endTime.equals(otherSlot.endTime);
    }

    @Override
    public String toString() {
        return "Year: " + year + ", Month: " + month + ", Day: " + day +
                ", Start Time: " + startTime + ", End Time: " + endTime;
    }
}
