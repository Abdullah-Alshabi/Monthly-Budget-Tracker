import java.util.Arrays;
import java.util.List;

public class StringOrdering {
    public static List<String> orderArrayOfString(String[] namesArray) {
        Arrays.sort(namesArray);
        return Arrays.asList(namesArray);
    }

    public static void main(String[] args) {
        String[] namesArray = {"Waleed", "Nawaf", "Ahmad", "Bandar", "Noor", "Alex"};
        List<String> namesOrdered = orderArrayOfString(namesArray);
        for (String tempName : namesOrdered) {
            System.out.print(" " + tempName);
        }
    }
}
