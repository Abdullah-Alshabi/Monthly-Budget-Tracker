public class Divider {
    public static double divide(int numerator, int denominator) {
        try {
            if (denominator == 0) {
                throw new ArithmeticException("Denominator cannot be zero");
            }
            return (double) numerator / denominator;
        } catch (ArithmeticException e) {
            System.out.println("Error: " + e.getMessage());
            return Double.NaN; // Or handle the error accordingly
        }
    }

    public static void main(String[] args) {
        double d1 = divide(100, 5);
        double d2 = divide(20, 0);
        System.out.println(d1);
        System.out.println(d2);
    }
}
