public class ExceptionHandling extends Exception{
    public static void main(String[] args) {
        try {
            String notNumber = "Hello";
            int[] arrayOfInt = new int[20];
            arrayOfInt[arrayOfInt.length] = 10;
            Integer.parseInt(notNumber);
        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (NumberFormatException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}
