import java.util.Random;

public class PasswordGenerator {
    public static String generatePassword(String aName) {
        if (aName == null || aName.length() < 3) {
            return null;
        }

        StringBuilder password = new StringBuilder();
        Random random = new Random();

        for (char c : aName.toCharArray()) {
            password.append(c);
            password.append(random.nextInt(10)); // Append a random digit
        }

        return aName.length() > 3 ? password.reverse().toString() : password.toString();
    }

    public static void main(String[] args) {
        String generatedPassword = generatePassword("Saleh");
        System.out.println(generatedPassword);
    }
}
