class Tablet extends Computer {
}
