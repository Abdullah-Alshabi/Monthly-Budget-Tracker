public class Computer {
     String brand;
     String condition;
     double screenSize;
     String hardDriveType;
     int ramSize;
    String cpu;

    public int getRam() {
        return ramSize;
    }

    public String getCPU() {
        return cpu;
    }

    public static boolean hasTouchScreen(Computer computer) {
        // Logic to check if the computer has a touch screen
        // Return true if it has, false otherwise
        return false; // Example logic
    }
}
