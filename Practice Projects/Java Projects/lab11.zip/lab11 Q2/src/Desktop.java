class Desktop extends Computer {
}
