class Laptop extends Computer {
}
