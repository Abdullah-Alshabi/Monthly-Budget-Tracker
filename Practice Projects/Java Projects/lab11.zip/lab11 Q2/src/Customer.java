import java.util.ArrayList;
import java.util.List;

class Customer {
    private String name;
    private List<Computer> computers;

    public Customer(String name) {
        if (name == null || name.isEmpty()) {
            throw new IllegalArgumentException("Name cannot be empty");
        }
        this.name = name;
        this.computers = new ArrayList<>();
    }

    public void addComputer(Computer computer) {
        computers.add(computer);
    }

    // Other methods specific to Customer
}
