public class TestComputer {
    public static void main(String[] args) {
        Computer computer1 = new Computer();
        computer1.brand = "BrandName";
        computer1.condition = "New";
        computer1.screenSize = 23.9;
        computer1.hardDriveType = "SSD";
        computer1.ramSize = 16;
        computer1.cpu = "i7";

        int ramSize = computer1.getRam();
        String cpu = computer1.getCPU();

        System.out.println("RAM Size: " + ramSize);
        System.out.println("CPU: " + cpu);
    }
}
