import java.util.ArrayList;

public class TestBarcode {
    public static void main(String[] args) {
        ArrayList<IBarcode> list = new ArrayList<>();
        list.add(new Tomato());
        list.add(new FrenchBreadItem());
        list.add(new Wheel());

        // Print all barcodes in the list
        for (IBarcode item : list) {
            System.out.println("Barcode: " + item.getBarcode());
        }
    }
}
