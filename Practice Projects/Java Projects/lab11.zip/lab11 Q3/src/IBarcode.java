interface IBarcode {
    int getBarcode();
}

class BakeryItem extends FoodItem {
    BakeryItem() {
        System.out.println("I am the BakeryItem");
    }

    public int getBarcode() {
        // Return BakeryItem barcode
        return 1001;
    }
}

class FoodItem implements IBarcode {
    FoodItem() {
        System.out.println("I am the FoodItem");
    }

    public int getBarcode() {
        // Return FoodItem barcode
        return 1002;
    }
}

class FrenchBreadItem extends BakeryItem {
    FrenchBreadItem() {
        System.out.println("I am the FrenchBreadItem");
    }

    public int getBarcode() {
        // Return FrenchBreadItem barcode
        return 1003;
    }
}

class Wheel extends CarItem {
    Wheel() {
        System.out.println("I am the Wheel");
    }

    public int getBarcode() {
        // Return Wheel barcode
        return 1004;
    }
}

class Tomato extends FruitItem {
    Tomato() {
        System.out.println("I am the Tomato");
    }

    public int getBarcode() {
        // Return Tomato barcode
        return 1005;
    }
}

class FruitItem extends FoodItem {
    FruitItem() {
        System.out.println("I am the FruitItem");
    }

    public int getBarcode() {
        // Return FruitItem barcode
        return 1006;
    }
}

class CarItem implements IBarcode {
    CarItem() {
        System.out.println("I am the CarItem");
    }

    public int getBarcode() {
        // Return CarItem barcode
        return 1007;
    }
}
