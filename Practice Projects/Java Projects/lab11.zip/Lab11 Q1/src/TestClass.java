public class TestClass {
    public static void main(String[] args) {
        AbstractClass obj = new ConcreteClass();
        System.out.println("Number: " + obj.getNumber()); // Prints the number

        System.out.println("Is Finished: " + obj.isFinished()); // Prints isFinished value
    }
}
