class ConcreteClass extends AbstractClass {
    // Implementing abstract method from AbstractClass
    int getNumber() {
        // Implementation logic here
        return 5; // Example logic
    }
}
