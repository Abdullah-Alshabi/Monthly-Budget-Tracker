interface ILab10Interface2 extends ILab10Interface1 {
    Boolean isHere();
}
