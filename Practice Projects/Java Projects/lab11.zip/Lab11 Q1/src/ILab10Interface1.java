interface ILab10Interface1 {
    Boolean isFinished();
}
