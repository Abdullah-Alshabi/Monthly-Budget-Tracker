abstract class AbstractClass {
    abstract int getNumber();

    // Implementing the isFinished() method from ILab10Interface1
    public Boolean isFinished() {
        // Implementation logic here
        return true; // Example logic
    }
}
