interface IParcode {
    int getParcode();

    void setParcode();
}