import java.time.LocalDateTime;
import java.util.regex.Pattern;

public class Customer implements IParcode {
    private String phoneNumber;
    private LocalDateTime enrolmentTime;
    private int parcode;

    public boolean setPhoneNumber(String phoneNumber) throws NullPointerException, NotValidPhoneException {
        if (phoneNumber == null) {
            throw new NullPointerException("Phone number cannot be null");
        }

        // Regex pattern for valid phone numbers
        String regex = "(05\\d{8})|(9665\\d{8})|(\\+9665\\d{8})";
        if (Pattern.matches(regex, phoneNumber)) {
            this.phoneNumber = phoneNumber;
            return true;
        } else {
            throw new NotValidPhoneException("Invalid phone number");
        }
    }

    public void addEnrolmentTime(LocalDateTime enrolmentTime) {
        this.enrolmentTime = enrolmentTime;
    }

    public static int compareCustomerEnrolmentTime(Customer customer1, Customer customer2) {
        return customer1.enrolmentTime.compareTo(customer2.enrolmentTime);
    }

    @Override
    public int getParcode() {
        return parcode;
    }

    @Override
    public void setParcode() {
        // Implementation of setParcode method
    }

    public static void main(String[] args) {
        Customer customer1 = new Customer();
        Customer customer2 = new Customer();

        try {
            customer1.setPhoneNumber("0555555555");
            customer2.setPhoneNumber("+966512345678");
        } catch (NullPointerException | NotValidPhoneException e) {
            e.printStackTrace();
        }

        LocalDateTime enrolmentTime1 = LocalDateTime.now();
        LocalDateTime enrolmentTime2 = LocalDateTime.now().plusHours(1);

        customer1.addEnrolmentTime(enrolmentTime1);
        customer2.addEnrolmentTime(enrolmentTime2);

        int comparison = Customer.compareCustomerEnrolmentTime(customer1, customer2);
        System.out.println("Comparison of enrolment times: " + comparison);
    }
}