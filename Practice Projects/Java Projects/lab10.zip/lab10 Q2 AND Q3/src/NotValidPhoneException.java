class NotValidPhoneException extends Exception {
    public NotValidPhoneException(String message) {
        super(message);
    }
}