import java.util.concurrent.TimeUnit;

public class DishWashingMachine {
    private String status;

    public DishWashingMachine() {
        this.status = "ready";
    }

    public void start() {
        try {
            if (status.equals("ready") || status.equals("wait")) {
                status = "running";
            } else if (status.equals("stop")) {
                status = "ready";
            }
        } catch (Exception e) {
            status = "error";
        }
    }

    public void wait(int minutes) {
        try {
            if (minutes <= 0 || minutes > 60) {
                throw new TimeFormatException("Invalid wait time");
            }
            TimeUnit.MINUTES.sleep(minutes);
        } catch (InterruptedException e) {
            status = "error";
        } catch (TimeFormatException e) {
            status = "error";
            System.out.println("Setting wait time to default: 10 minutes");
            try {
                TimeUnit.MINUTES.sleep(10);
            } catch (InterruptedException ex) {
                status = "error";
            }
        }
    }

    public void stop() {
        try {
            if (status.equals("running") || status.equals("wait")) {
                status = "stop";
            } else if (status.equals("error")) {
                status = "stop";
            }
        } catch (Exception e) {
            status = "error";
        }
    }

    public String getStatus() {
        return status;
    }

    public static void main(String[] args) {
        DishWashingMachine machine = new DishWashingMachine();
        machine.start();
        machine.wait(70);
        machine.stop();
        System.out.println("Machine Status: " + machine.getStatus());
    }
}
